	import java.util.Scanner;

public class Driver {

		public static void main(String[] args) 
		{

			Scanner game = new Scanner(System.in);
			
			System.out.print("How many rows are in the maze? ");
			int rows = game.nextInt();
			
			System.out.print("How many columns are in the maze? ");
			int columns = game.nextInt();
			
			//array and for loop for asking the danger levels of each cell
			
			int [][] world = new int[rows][columns];
			for(int i=0; i < rows; i++)
			{
				System.out.print("Enter the danger in row " + i + ", separated by spaces: ");

					for(int j=0; j < columns; j++)
					{
						world[i][j] = game.nextInt();	
					}
			}
			
			//x and y coordinate prompted and world displayed with *
			System.out.print("Enter the starting x coordinate: ");
			int x = game.nextInt();
			System.out.print("Enter the starting y coordinate: ");
			int y = game.nextInt();
			
			  
			
			//Parts 3, 4, and 5
			//Initialize String which keeps track of the position the AI character is in
			String visited = new String(" ");
			visited = visited + x + " ," + y;
			//total danger
			int totalDanger = world[x][y];

			for(int i=0; i < world.length; i++)
			{
				for(int j =0; j < world[i].length; j++)
				{
					if(x==i && y==j)
					{
						System.out.print("* ");
					}
					else 
					{
					System.out.print(world[i][j] + " ");
					}
					
				}
				System.out.println();

			}
			System.out.println(" ");
			
			if(x==0 || y==0 || x==rows-1 || y==columns-1)
			{
				System.out.println("Exited the world at " + x + "," + y);
				System.out.println("Total danger faced: " + world[x][y]);
			}
			while(x!=0 && y!=0 && x!=rows-1 && y!=columns-1)
			{
				
				int north = world[x-1][y];
				int south = world[x+1][y];
				int east = world[x][y+1];
				int west = world[x][y-1];
				
				if(north <= south && north <= east && north <= west && !visited.contains((x-1) + " ," + y))
				{
					x=x-1;
					y=y;
					visited = visited + x + " ," + y;
					totalDanger = totalDanger + north;
				}
				else if(south <= east && south <= west && !visited.contains((x+1) + " ," + y))
				{
					x=x+1;
					y=y;
					visited = visited + x + " ," + y;
					totalDanger = totalDanger + south;

				}
				else if(east <= west && !visited.contains(x + " ," + (y+1)))
				{
					x=x;
					y=y+1;
					visited = visited + x + " ," + y;
					totalDanger = totalDanger + east;

				}
				else if(!visited.contains(x + " ," + (y-1)))
				{
					x=x;
					y=y-1;
					visited = visited + x + " ," + y;
					totalDanger = totalDanger + west;

				}
				else
				{
					System.out.println("You're Stuck!");
				}
				

				System.out.println("Moving to " + x + "," + y + " (danger level " + world[x][y] + ")" );
				for(int i=0; i < rows; i++)
				{
					for(int j=0; j < columns; j++)
					{
						if(x==i && y==j)
						{
							System.out.print("* ");
						}
						else {
							System.out.print(world[i][j] + " ");
						}
					}
					System.out.println();
				}
				System.out.println(" ");
				
				if(x==0 || y==0 || x==rows-1 || y==columns-1)
				{
					System.out.println("Exited the world at " + x + "," + y);
					System.out.println("Total danger faced: " + totalDanger);
				}
				
			}
			
			
			
			
			
		}

	}
